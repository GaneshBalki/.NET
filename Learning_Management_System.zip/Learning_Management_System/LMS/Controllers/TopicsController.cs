using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LMS.Models;
using BLL;
using BOL;

namespace LMS.Controllers;

public class TopicsController : Controller
{
    private readonly ILogger<TopicsController> _logger;

    public TopicsController(ILogger<TopicsController> logger)
    {
        _logger = logger;
    }

    
    
    public IActionResult TrainingTopics()
    {
        TrainingManager trainigMGR=new TrainingManager();
        List<Topic> topicsList=trainigMGR.GetAllTopics();
        ViewData["topicsList"] = topicsList;
        return View();
    }

    
     public IActionResult UpdateTopic()
    {
       
         return  View();
       
    }

    [HttpPost]
    public IActionResult Update(string name, string desc,string loc)
    {
        Console.WriteLine("In Update Method");
       Topic t = new Topic{
                                        
                                        Name=name,
                                        Description=desc,
                                        Location=loc
       };
       TrainingManager trainigMGR=new TrainingManager();
       bool status=trainigMGR.UpdateTopic(t);
           Console.WriteLine("In Update Method  222");
 
      if(status)
           { 
            return RedirectToAction("TrainingTopics","Topics");
           }
               Console.WriteLine("In Update Method   3333");
        return View();
    }
    
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
