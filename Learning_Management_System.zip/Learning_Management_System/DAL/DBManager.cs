﻿namespace DAL;
using BOL;
using MySql.Data.MySqlClient;

public class DBManager
{
    public static string conString = @"server=192.168.10.150;port=3306;user=dac32;password=welcome;database=dac32";

    public static List<Topic> GetAllTopics()
    {
        List<Topic> tlist = new List<Topic>();
        MySqlConnection con=new MySqlConnection(conString);
        try
        {
            con.Open();
            string query = "SELECT * From Topics";
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = query;
            MySqlDataReader reader=cmd.ExecuteReader();
            while (reader.Read())
            {
                string name = reader["name"].ToString();
                string description = reader["description"].ToString();
                string faculty = reader["faculty"].ToString();
                string location = reader["location"].ToString();
                
                Topic t = new Topic {
                    Name = name,
                    Description = description,
                    Faculty = faculty,  
                    Location = location
                };

                tlist.Add(t);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return tlist;
    } 
 public static bool UpdateTopic(Topic t)
    {
        bool status = false;
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        String Query = "update Topics set name = '"+t.Name+"',Description = '"+t.Description+"', location ='"+t.Location+"' where name="+t.Name;
        try
        {
            con.Open();
            MySqlCommand cmd = new MySqlCommand(Query);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            status=true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return status;
    }


}