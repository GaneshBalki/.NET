﻿namespace BLL;
using BOL;
using DAL;
public class TrainingManager
{
   public List<Topic> GetAllTopics()
    {
        List<Topic> allTopics = DBManager.GetAllTopics();
        return allTopics;
    }

    public bool UpdateTopic(Topic t){
        bool status=DBManager.UpdateTopic(t);
        return status;
    }
}
