﻿namespace BOL;

public class Topic
{

    public string Name { get; set; }
    public string Description { get; set; }
    public string Faculty { get; set; }
    public string Location { get; set; }

}
