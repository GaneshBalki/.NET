﻿namespace BOL;

public class Class1
{

}
