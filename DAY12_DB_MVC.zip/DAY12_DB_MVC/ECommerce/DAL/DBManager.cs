namespace DAL;   
using BOL;                                                                                                                                                                       
using System.Collections;
using MySql.Data.MySqlClient;
public class DBManager
{
    public static string conString = @"server=192.168.10.150;port=3306;user=dac32; password=welcome;database=dac32";

    public static List<Customer> GetAllCustomer()
    {
        List<Customer> clist = new List<Customer>();
        MySqlConnection conn = new MySqlConnection();
        conn.ConnectionString = conString;
        try
        {
           
            String query = "Select * from Customer2207";
          
            MySqlCommand cmd = new MySqlCommand(query,conn);
            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = int.Parse(reader["id"].ToString());
                string fname = reader["fname"].ToString();
                string lanme = reader["Lname"].ToString();
                Customer c1=new Customer{ID=id,Fname=fname,Lname=lanme};
                clist.Add(c1);
    
            }


        }
        catch (Exception e)
        {

            throw e;
        }
        finally
        {
            conn.Close();
        }

        return clist;


    }

    public static int RemoveCustomer(int id){
       MySqlConnection conn = new MySqlConnection();
        conn.ConnectionString = conString;
        try
        {
           
            String query = "delete from Customer2207 where id="+id;
          
            MySqlCommand cmd = new MySqlCommand(query,conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            return 1;


        }
        catch (Exception e)
        {
 return 0;
            throw e;
        }
        finally
        {
            conn.Close();
        }

       
    }
}

    /*
    public static Department GetDeptById(int id){
        Department dept = null;
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try
        {
            string query = "SELECT * FROM departments WHERE id=" + id;
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            MySqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                id = int.Parse(reader["id"].ToString());
                string name = reader["name"].ToString();
                string location = reader["location"].ToString();
                dept = new Department
                {
                    Id = id,
                    Name = name,
                    Location = location
                };
            }

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }
        return dept;
    }

    
 public static bool Insert(Department dept){
        bool status=false;
        string query = "INSERT INTO departments(id,name,location)" +
                            "VALUES("+dept.Id+","+"'" + dept.Name + "','" + dept.Location + "')";

        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try{
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            command.ExecuteNonQuery();  //DML
            status = true;
        } 
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }               
        return status;
     }
    public static bool Update(Department dept)
    {
        bool status = false;
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try
        {
            string query = "UPDATE departments SET location='" + dept.Location + "', name='" + dept.Name + "' WHERE id=" + dept.Id;
            MySqlCommand command = new MySqlCommand(query, con);
            con.Open();
            command.ExecuteNonQuery();
            status = true;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }
        return status;
    }
}*/