﻿namespace BLL;
using BOL;
using DAL;
public class CustomerMGR
{
      public  List<Customer> GetAllCustomers(){
        List<Customer> allCustomers = new List<Customer>();
        allCustomers=DAL.DBManager.GetAllCustomer();
        //filter department which are not performing
        //Sort all Deparment based on
        //number of employees work in dept
        //List<Customer> sortedPerformingDepartments = allDepartments;
        return allCustomers;
    }

    public int RemoveCustomer(int id){
      int status=DAL.DBManager.RemoveCustomer(id);
      return status;
    }
}
