using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EStore.Models;
using BLL;
using BOL;
namespace EStore.Controllers;

public class CustomerController : Controller
{
    private readonly ILogger<CustomerController> _logger;

    public CustomerController(ILogger<CustomerController> logger)
    {
        _logger = logger;
    }


    public IActionResult Index()
    {
        CustomerMGR cmg=new CustomerMGR();
        List<Customer> clist=cmg.GetAllCustomers();
        this.ViewData["customersList"]=clist;
        return View();
    }

    public IActionResult Delete(int id)
    {
       //return RedirectToAction("Index","Home");
       CustomerMGR cmg=new CustomerMGR();
       int status=cmg.RemoveCustomer(id);
       return RedirectToAction("Index");
    }
  

    public IActionResult Insert(){
           return View();
    }

       public JsonResult Customers()
    {
        List<Customer> customers=new List<Customer>();
        customers.Add(new Customer {   ID=12,Fname="Ravi",Lname="Tambade"} );
        customers.Add(new Customer{  ID=13, Fname="Amit",Lname="Khedkar"} );
       //Create bussiness Logic  manager instance
       //Invoke Bussiness Manager GetAll Trainers method
       //retrieved list<Trainer>  pass to Json Method
        return Json(customers);
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
