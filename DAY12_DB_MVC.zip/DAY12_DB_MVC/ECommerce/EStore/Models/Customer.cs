namespace EStoreWebApp.Models
{
    public class Customer
    {
        public int ID{get;set;}
        public string Fname { get;set; }
         public string Lname { get;set; }
        
    }
}
